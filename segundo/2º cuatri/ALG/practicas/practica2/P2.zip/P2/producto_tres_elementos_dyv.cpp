#include <iostream>
#include <cmath>
#include <fstream>
#include <chrono>
using namespace std;

int producto_3_elementos(int num, int ini, int fin){
	if (ini > fin)
		return -1;
		
	int media = (fin + ini)/2;
	int producto = media * (media+1) * (media + 2);
	
	if (producto == num)
		return media;
	else if (producto > num){
		fin = media - 1;
		producto_3_elementos(num, ini, fin);
	}
	else {
		ini = media + 1;
		producto_3_elementos(num, ini, fin);
	}
}

int main(int argc, char* argv[]){
	int num_elem, incr, valor;
	long long n;
   chrono::time_point<std::chrono::high_resolution_clock> t0, tf; // Para medir el tiempo de ejecución
	unsigned long int semilla;
	ofstream fsalida;
 	 	
 	if (argc != 5) {
		cerr<<"\nError: El programa se debe ejecutar de la siguiente forma.\n\n";
		cerr<<argv[0]<<" NombreFicheroSalida Semilla tamCaso Incremento\n\n";
		return 0;
	}	
	
	// Abrimos fichero de salida
	fsalida.open(argv[1]);
	if (!fsalida.is_open()) {
		cerr<<"Error: No se pudo abrir fichero para escritura "<<argv[1]<<"\n\n";
		return 0;
	}
	
	// Calculamos un valor entre 10000 y 100000 mediante la semilla
   semilla = atoi(argv[2]);
   srand(semilla);
    n = (rand() % 100000) + 100;
    
	num_elem = atoi(argv[3]);
	incr = atoi(argv[4]);
	
	int ini = 1;
	int fin = n / 3;	//Creamos fin con valor num/3, ya que que el producto de num*(num+1)*(num+2) > num
	// Iniciando con "n", ejcutaremos la función sobre "n" "elem" veces sumándole "incremento" en cada iteración
	//iniciamos 
	for(int i = 0; i < num_elem; i++){
		t0= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que comienza la ejecución del algoritmo
		for(int j = 0; j < 10000; j++){
            valor = producto_3_elementos(n, ini, fin); 
        }
		tf= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que finaliza la ejecución del algoritmo
	
		unsigned long long tejecucion= std::chrono::duration_cast<std::chrono::microseconds>(tf - t0).count();
		
		cerr << "\tTiempo de ejec. (us): " << tejecucion << " para n = "<< n<<endl;
		
		// Guardamos n y t_ejecucion a fichero de salida
		fsalida<<n<<" "<<tejecucion<<"\n";	

		n += incr;
	}
}

/*int producto_3_elementos(int num){
	int cont = 1;
	int producto = 0;
	
	while (cont < sqrt(num)){
		producto = cont * (cont+1) * (cont+2);
		
		if (producto == num)
			return cont;
		else if (producto < num)
			cont++;
		else
			return -1;
	}
}*/
