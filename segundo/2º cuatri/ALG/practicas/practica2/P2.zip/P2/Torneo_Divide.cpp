#include <iostream>
#include <vector>
#include <cmath>
#include <set>
#include <cstdlib> 
#include <chrono>
#include <fstream> 

using namespace std;



// Función que construye el calendario del torneo
void construir_calendario(vector<vector<int>> &calendario, int primero, int ultimo)
{
    //
    if (ultimo - primero == 1)
    {
        calendario[primero][0] = ultimo;
        calendario[ultimo][0] = primero;
    }
    else 		//general
    {
        int mitad = ((primero + ultimo) / 2);
        construir_calendario(calendario, primero, mitad);    // Primero juegan los primeros jugadores contra los primeros jugadores
        construir_calendario(calendario, mitad + 1, ultimo); // luego ultimos contra ultimos
        completar_calendario(calendario, primero, mitad, mitad - primero, ultimo - primero - 1, mitad + 1);
        // Aqui primeros contra ultimos
        completar_calendario(calendario, mitad + 1, ultimo, mitad - primero, ultimo - primero - 1, primero);
        // y los ultimos contra los primeros
    }
}

void completar_calendario(vector<vector<int>> &calendario, int primero, int ultimo, int primer_dia, int ultimo_dia,
                         int primer_adversario)
{
    // El primer jugador va jugando contra los demas en orden
    for (int j = primer_dia; j <= ultimo_dia; j++)
    {
        calendario[primero][j] = primer_adversario + j - primer_dia;
    }

    
    for (int i = primero + 1; i <= ultimo; i++)
    {
        // Intercambio
        calendario[i][primer_dia] = calendario[i - 1][ultimo_dia];

        // Rotación
        for (int j = primer_dia + 1; j <= ultimo_dia; j++)
        {
            calendario[i][j] = calendario[i - 1][j - 1];
        }
    }
}

int main()
{
    int num_participantes;
    cout << "Introduce el número de participantes: ";
    cin >> numero_participantes;

    //Debe ser potencia de 2
    if ((n & (n - 1)) != 0)
    {
        cout << "El número de participantes debe ser una potencia de 2" << endl;
        return 0;
    }

    vector<vector<int>> calendario (num_participantes, vector<int>(num_participantes - 1));
    construir_calendario(calendario, 0, num_participantes - 1);
    // Imprimir el calendario del torneo
    cout << "Calendario del Torneo:" << endl;
    for (int i = 0; i < n; i++)
    {
        cout << "Participante " << i << ": ";
        for (int j = 0; j < n - 1; j++)
        {
            cout << calendario[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
