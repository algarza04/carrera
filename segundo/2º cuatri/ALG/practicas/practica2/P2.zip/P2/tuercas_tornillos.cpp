#include <chrono>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cstring>


using namespace std;

void FuerzaBruta(vector<int> tu, vector<int> to, int n);
void DIV(vector<int> tu, vector<int> to, vector<int> ord, int n, int m);
void Desordenar(vector<int>v, int n);

int main(int argc, char *argv[]){
	int n, argumento;
    chrono::time_point<std::chrono::high_resolution_clock> t0_bruta, tf_bruta, t0_DIV, tf_DIV; // Para medir el tiempo de ejecución
	unsigned long int semilla;
	ofstream fsalida;
	
	if (argc <= 2) {
		cerr<<"\nError: El programa se debe ejecutar de la siguiente forma.\n\n";
		cerr<<argv[0]<<" NombreFicheroSalida tamCaso1 tamCaso2 ... tamCasoN\n\n";
		return 0;
	}
	
	// Abrimos fichero de salida
	fsalida.open(argv[1]);
	if (!fsalida.is_open()) {
		cerr<<"Error: No se pudo abrir fichero para escritura "<<argv[1]<<"\n\n";
		return 0;
	}
	
	
	// Pasamos por cada tamaÒo de caso
	for (argumento= 2; argumento<argc; argumento++) {
		
		// Cogemos el tamanio del caso
		n= atoi(argv[argumento]);
		
		// Reservamos memoria para los vectores
		vector<int> tuercas(n);
		vector<int> tornillos(n);
		vector<int> tuercas_DIV(n);
		vector<int> tornillos_DIV(n);
		vector<int> ord(n);
	
		for (int i= 0; i<n; i++){
			tuercas[i]= i;
			tornillos[i] = i;
		}
		
		//Desordenamos los vectores
		Desordenar(tornillos,n);
		Desordenar(tuercas,n);
		
		tuercas_DIV=tuercas;
		tornillos_DIV=tornillos;
		ord = tornillos;
		
		
		cerr << "Ejecutando tuercas y tornillos de fuerza bruta para tam. caso: " << n << endl;
		
		t0_bruta= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que comienza la ejecuciÛn del algoritmo
		FuerzaBruta(tuercas, tornillos, n); // Ejecutamos el algoritmo para tamaÒo de caso tam
		tf_bruta= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que finaliza la ejecuciÛn del algoritmo
		
		unsigned long tejecucion= std::chrono::duration_cast<std::chrono::microseconds>(tf_bruta - t0_bruta).count();
		
		cerr << "\tTiempo de ejec fuerza bruta. (us): " << tejecucion << " para tam. caso "<< n<<endl;
		
		// Guardamos tam. de caso y t_ejecucion a fichero de salida
		fsalida<<"Tiempo de ejec fuerza bruta: " << tejecucion << " para tam. caso "<< n<<endl;

		cerr << "Ejecutando tuercas y tornillos DIV para tam. caso: " << n << endl;
		
		t0_DIV= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que comienza la ejecuciÛn del algoritmo
		DIV(tuercas_DIV, tornillos_DIV, ord, n, n); // Ejecutamos el algoritmo para tamaÒo de caso tam
		tf_DIV= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que finaliza la ejecuciÛn del algoritmo
		
		tejecucion= std::chrono::duration_cast<std::chrono::microseconds>(tf_DIV - t0_DIV).count();
		
		cerr << "\tTiempo de ejec DIV. (us): " << tejecucion << " para tam. caso "<< n<<endl;
		
		// Guardamos tam. de caso y t_ejecucion a fichero de salida
		fsalida<<"Tiempo de ejec DIV: " << tejecucion << " para tam. caso "<< n<<endl;
		
	}
	
	// Cerramos fichero de salida
	fsalida.close();
	
	return 0;
}


void FuerzaBruta(vector<int> tu, vector<int> to, int n) {
	for(int i = 0; i < n; i ++ ){
		for(int j = i; j < n; j++){
			if( tu[i] == to[j] ){
				swap(to[i], to[j]);
				j = n; //Para que se salga del bucle
			}
		}
	}
}

void DIV(vector<int> tu, vector<int> to, vector<int> ord, int n, int m){
	if(m  > 3 ) { // Ponemos un numero pequeño
		if ( m%2==0){
			vector<int> mitad1(to.begin(), to.begin() + m / 2);
        		vector<int> mitad2(to.begin() + m / 2, to.end());
			DIV(tu, mitad1, ord, n, m/2); // Llama a la funcion dividiendo el vector en dos
			DIV(tu, mitad2, ord, n, m/2);
		}else{
			vector<int> uno(to.begin(), to.begin() + 1);
        		vector<int> mitad1(to.begin() +1 , to.begin()+ m /2);
        		vector<int> mitad2(to.begin() + m / 2, to.end());
			DIV(tu, uno, ord, n, 1); 
			DIV(tu, mitad1, ord, n, (m-1)/2);
			DIV(tu, mitad2, ord, n, (m-1)/2); 
		}
	}else{
		switch(m){
			case 1: 
				for (int i = 0; i < n; i ++){
					if(tu[i] == to[0]){
						ord[i] = tu[0];
						i = n;
					}
				}
			break;
			case 2: 
				for (int i = 0; i < n; i ++){
					if(tu[i] == to[0])
						ord[i] = tu[0];
					if(tu[i] == to[1])
						ord[i] = tu[1];
				}
			break;
			case 3: 
				for (int i = 0; i < n; i ++){
					if(tu[i] == to[0])
						ord[i] = tu[0];
					if(tu[i] == to[1])
						ord[i] = tu[1];
					if(tu[i] == to[2])
						ord[i] = tu[2];
				}
			break;
		}
	}
}

void Desordenar(vector<int> v, int n){
	vector<int> aux(n);
	vector<int> usado(n);
	for (int i=0; i < n; i++)
   		usado[i]=false;

	int indice=0;
	for (int i=0; i < n; i++){
    		do{
       			indice = (rand() % n);
    		}while (usado[indice]);
    		aux[i] = v[indice];
		usado[indice]=true;
	}
	for (int i=0; i < n; i++){
		v[i] = aux[i];
	}
}

/***************************************************************************/
/***************************************************************************/

