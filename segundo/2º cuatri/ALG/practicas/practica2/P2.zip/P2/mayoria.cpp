#include<iostream>
#include <vector>
#include <map>
using namespace std;

int fuerzaBruta(vector<int> &v){
    map<int,int> m;
    int mayoria=(v.size()/2)+1;
    for (auto i = v.begin(); i != v.end(); ++i){
        auto it = m.find(*i);
        if (it!=m.end()){
            it->second++;
            if (it->second >= mayoria){
                return it->first;
            }
        }
        else
            m.insert(make_pair(*i,1));
    }
    return -1;
}

bool isMajority(vector<int>& nums, int candidate) {
    int count = 0;
    int n = nums.size();
    for (int i = 0; i < n; ++i) {
        if (nums[i] == candidate) {
            ++count;
        }
    }

    return count > n / 2;
}

int majorityElementUtil(vector<int>& nums, int left, int right) {
    if (left == right) {
        return nums[left];
    }

    int mid = left + (right - left) / 2;
    int leftMajority = majorityElementUtil(nums, left, mid);
    int rightMajority = majorityElementUtil(nums, mid + 1, right);

    if (leftMajority == rightMajority) {
        return leftMajority;
    }

    int leftCount = 0, rightCount = 0;
    for (int i = left; i <= right; ++i) {
        if (nums[i] == leftMajority) {
            ++leftCount;
        } else if (nums[i] == rightMajority) {
            ++rightCount;
        }
    }

    return leftCount > rightCount ? leftMajority : rightMajority;
}

int majorityElement(vector<int>& nums) {
    int candidate = majorityElementUtil(nums, 0, nums.size() - 1);

    if (isMajority(nums, candidate)) {
        return candidate;
    }

    return -1; // No hay mayoría absoluta
}

int main(){

    vector<int>prueba={1,2,3,4,5,6,7,8,9,1,3,2,1,1,2,5,6,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,4,4,5,9,7,5,1,1,1,1,2,1,5,9,7,2,3,9,7,1,6,1,1,1,15,6,8,4,1,65,8,1,45,1,1,1,5,6,9,9,9,9,9,9};
    vector<int>prueba2={1,1,1,2,3,3,2,2};
    cout<<fuerzaBruta(prueba)<<endl;
    cout <<majorityElement(prueba)<<endl;
    cout<<fuerzaBruta(prueba2)<<"\n"<<majorityElement(prueba2)<<endl;

    return 0;
}