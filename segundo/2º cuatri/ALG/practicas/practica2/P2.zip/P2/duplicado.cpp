
#include <cstdlib> // Para usar srand y rand
#include <chrono>
#include <iostream>
#include <fstream> // Para usar ficheros
#include <vector>
#include <algorithm>
using namespace std;

// Fuerza bruta
void FuerzaBruta(int* array, size_t size) {
    size_t newSize = 0;

    for (size_t i = 0; i < size; ++i) {
        size_t j;
        for (j = 0; j < newSize; ++j) {
            if (array[i] == array[j]) {
                j = newSize + 1;
            }
        }
        if (j == newSize) {
            array[newSize] = array[i];
            newSize++;
        }
    }
}


void merge(int* arr, int l, int m, int r, int* temp) {
    int i = l;
    int j = m + 1;
    int k = l;

    while (i <= m && j <= r) {
        if (arr[i] < arr[j]) {
            temp[k++] = arr[i++];
        } else if (arr[j] < arr[i]) {
            temp[k++] = arr[j++];
        } else {
            temp[k++] = arr[i++];
            j++;
        }
    }

    while (i <= m) {
        temp[k++] = arr[i++];
    }

    while (j <= r) {
        temp[k++] = arr[j++];
    }

    for (i = l; i <= r; i++) {
        arr[i] = temp[i];
    }
}

void mergeSort(int* arr, int l, int r, int* temp) {
    if (l < r) {
        int m = l + (r - l) / 2;

        mergeSort(arr, l, m, temp);
        mergeSort(arr, m + 1, r, temp);

        merge(arr, l, m, r, temp);
    }
}


int main(int argc, char *argv[]) {

	int *v;
	int n, i, argumento;
    chrono::time_point<std::chrono::high_resolution_clock> t0, tf; // Para medir el tiempo de ejecución
	unsigned long int semilla;
	ofstream fsalida;

	if (argc <= 3) {
		cerr<<"\nError: El programa se debe ejecutar de la siguiente forma.\n\n";
		cerr<<argv[0]<<" NombreFicheroSalida Semilla tamCaso1 tamCaso2 ... tamCasoN\n\n";
		return 0;
	}

	// Abrimos fichero de salida
	fsalida.open(argv[1]);
	if (!fsalida.is_open()) {
		cerr<<"Error: No se pudo abrir fichero para escritura "<<argv[1]<<"\n\n";
		return 0;
	}

	// Inicializamos generador de no. aleatorios
	semilla= atoi(argv[2]);
	srand(semilla);


// Creamos dos vectores para almacenar los tamaños de los casos y los tiempos de ejecución
vector<int> tamanios;
vector<unsigned long> tiemposDivideYVenceras;
vector<unsigned long> tiemposFuerzaBruta;

// Pasamos por cada tamaño de caso
for (argumento= 3; argumento<argc; argumento++) {

    // Cogemos el tamanio del caso
    n= atoi(argv[argumento]);
    tamanios.push_back(n);

    // Reservamos memoria para el vector
    v= new int[n];
    int* temp = new int[n];
    
    int* v2 = new int[n];  //copiamos el array



    // Generamos vector aleatorio de prueba, con componentes entre 0 y n-1
    for (i= 0; i<n; i++)
        v[i]= rand()%n;
        
        for (int i = 0; i < n; i++) {
    v2[i] = v[i];  
}
        

    cerr << "Ejecutando DivideYVenceras para tam. caso: " << n << endl;

    t0= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que comienza la ejecución del algoritmo
   mergeSort(v2, 0, n-1, temp); // Ejecutamos el algoritmo para tamaño de caso tam
    tf= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que finaliza la ejecución del algoritmo

    unsigned long tejecucion= std::chrono::duration_cast<std::chrono::microseconds>(tf - t0).count();

    cerr << "\tTiempo de ejec. (us): " << tejecucion << " para tam. caso "<< n<<endl;

    // Guardamos el tiempo de ejecución en el vector correspondiente
    tiemposDivideYVenceras.push_back(tejecucion);

    cerr << "Ejecutando FuerzaBruta para tam. caso: " << n << endl;

    t0= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que comienza la ejecución del algoritmo
    FuerzaBruta(v, n); // Ejecutamos el algoritmo para tamaño de caso tam
    tf= std::chrono::high_resolution_clock::now(); // Cogemos el tiempo en que finaliza la ejecución del algoritmo

    tejecucion= std::chrono::duration_cast<std::chrono::microseconds>(tf - t0).count();

    cerr << "\tTiempo de ejec. (us): " << tejecucion << " para tam. caso "<< n<<endl;

    // Guardamos el tiempo de ejecución en el vector correspondiente
    tiemposFuerzaBruta.push_back(tejecucion);

    // Liberamos memoria del vector
    delete [] v;
    delete[] v2;
}

// Ahora escribimos los tamaños de los casos y los tiempos de ejecución en el fichero de salida
fsalida << "DivideYVenceras:\n";
for (size_t i = 0; i < tamanios.size(); ++i) {
    fsalida << tamanios[i] << " " << tiemposDivideYVenceras[i] << "\n";
}

fsalida << "FuerzaBruta:\n";
for (size_t i = 0; i < tamanios.size(); ++i) {
    fsalida << tamanios[i] << " " << tiemposFuerzaBruta[i] << "\n";
}





	// Cerramos fichero de salida
	fsalida.close();

	return 0;
}
