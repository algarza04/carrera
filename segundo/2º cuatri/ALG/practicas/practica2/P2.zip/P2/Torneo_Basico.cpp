#include <iostream>
#include <vector>
#include <cmath>
#include <set>

using namespace std;


vector<vector<int>> construir_calendario(int n)
{

    vector<vector<int>> calendario(n, vector<int>(n - 1, 0)); 
    vector<set<int>> partidos_dia(n-1);
    set<int>contrincantes; 
    
    bool insertado;
    for (int i = 0; i < n; i++)
    {
        contrincantes.clear();
        contrincantes.insert(i);
        for (int j = 0; j < n - 1; j++)
        {
            insertado = false;
            if (i == 0) // El primer jugador va jugando contra los demas en
            {
                calendario[i][j] = j + 1;
                partidos_dia[j].insert(j + 1);
            }
            else
            {
                for (int k = i - 1; k >= 0 && !insertado; k--)
                {
                    if (calendario[k][j] == i)  // se hace si el jugador i ya tenia un partido en el dia j
                    {
                        calendario[i][j] = k;
                        partidos_dia[j].insert(k);
                        contrincantes.insert(k);
                        insertado = true;
                    }
                }
                if (!insertado) // Si no lo tiene, se prueba con los demás jugadores hasta encontrar a uno que no haya jugado con él
                    {           // ni tenga otro partido ese mismo día
                        for (int l=0; l<n && !insertado; l++)
                        {
                            insertado = false;
                            if (partidos_dia[j].find(l) == partidos_dia[j].end() && contrincantes.find(l) == contrincantes.end()
                                && l != i)
                            {
                                calendario[i][j] = l;
                                partidos_dia[j].insert(l);
                                contrincantes.insert(l);
                                insertado = true;
                            }
                        }
                    }
            }
        }
    }

    return calendario;
}

int main()
{
    int num_participantes;
    cout << "Introduce el número de participantes: ";
    cin >> num_participantes;

    //Debe ser potencia de 2
    if ((n & (n - 1)) != 0)
    {
        cout << "El número de participantes debe ser una potencia de 2" << endl;
        return 0;
    }

    vector<vector<int>> calendario = construir_calendario(n);

    // Imprimir el calendario del torneo
    cout << "Calendario del Torneo:" << endl;
    for (int i = 0; i < n; i++)
    {
        cout << "Participante " << i << ": ";
        for (int j = 0; j < n - 1; j++)
        {
            cout << calendario[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
