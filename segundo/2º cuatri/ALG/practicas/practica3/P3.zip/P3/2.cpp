#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int encuentraMaximo (vector<int> &vectorConvivencia){
	int max =0;
	int index;
	for( int i=0; i<vectorConvivencia.size(); i++){
		if (max < vectorConvivencia[i]){
			max = vectorConvivencia[i];
			index = i;
		}
	}
	return index;
}


void asignarAsientos(vector<vector<int>>& conveniencia) {
	int n = conveniencia.size(),conv,i=0,nSentados=0;
	vector<int>orden;//aprovecho que el vector por defecto tiene tamaño 1 y se inicia a 0
	cout<<"invitao 0 sentao"<<endl;
	while (nSentados<n-1){
		conv=encuentraMaximo(conveniencia[i]);
		orden.push_back(conv);
		for (int e=0; e<n; e++){
				conveniencia[i][e]=0;
				conveniencia[e][i]=0;
		}
		i=conv;
		cout<<"invitado "<<i<<" sentao"<<endl;
		nSentados++;

	}

	// Mostrar la disposición de los invitados en la mesa
	for (int i = 0; i < n; ++i) {
	cout << orden[i]<<" ";
	}
	cout<<endl;
}

int main() {
    // Ejemplo de matriz de conveniencia entre los invitados
    vector<vector<int>> conveniencia = {
        {0, 40, 90, 7},
        {40, 0, 85, 75}, 
        {90, 85, 0, 80},
        {7, 75, 80, 0}
    };

    // Llamar a la función para asignar los asientos
    asignarAsientos(conveniencia);

    return 0;
}