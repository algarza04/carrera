#include <iostream>
#include <vector>

using namespace std;

// Definici�n de una estructura para representar una gasolinera
struct Gasolinera {
    int distancia;
    int costo_combustible;
};

// Funci�n auxiliar para verificar si hay suficientes kil�metros de combustible para llegar al siguiente nodo
bool kilometrosSuficientes(int distancia_siguiente, int capacidad_tanque) {
    return distancia_siguiente <= capacidad_tanque;
}

// Funci�n auxiliar para decidir el siguiente nodo a visitar
int decidirNodo(const vector<Gasolinera>& gasolineras, int distancia_actual, int capacidad_tanque) {
    int mejor_opcion = -1;
    double mejor_ratio = 200; // Inicializar con un valor grande de doble precisi�n

    // Iterar sobre todas las gasolineras disponibles
    for (int i = 0; i < gasolineras.size(); ++i) {
        int distancia_a_gasolinera = gasolineras[i].distancia - distancia_actual;
        // Verificar si tenemos suficiente combustible para llegar a esta gasolinera
        if (kilometrosSuficientes(distancia_a_gasolinera, capacidad_tanque)) {
            double ratio = static_cast<double>(gasolineras[i].costo_combustible) / distancia_a_gasolinera;
            // Actualizar si encontramos una opci�n mejor
            if (ratio < mejor_ratio) {
                mejor_ratio = ratio;
                mejor_opcion = i;
            }
        }
    }
    return mejor_opcion;
}

// Funci�n principal que implementa el algoritmo voraz
void algoritmoVoraz(const vector<Gasolinera>& gasolineras, int distancia_total, int capacidad_tanque) {
    int distancia_actual = 0;
    vector<int> ruta;

    while (distancia_actual < distancia_total) {
        int siguiente_gasolinera = decidirNodo(gasolineras, distancia_actual, capacidad_tanque);
        if (siguiente_gasolinera == -1) {
            cout << "No hay suficientes gasolineras para llegar al destino." << endl;
            return;
        }
        ruta.push_back(siguiente_gasolinera);
        distancia_actual = gasolineras[siguiente_gasolinera].distancia;
    }

    // Imprimir la ruta seleccionada
    cout << "Ruta seleccionada:" << endl;
    for (int i = 0; i < ruta.size(); ++i) {
        cout << "Gasolinera " << ruta[i] << ": Distancia: " << gasolineras[ruta[i]].distancia
             << ", Costo de combustible: " << gasolineras[ruta[i]].costo_combustible << endl;
    }
}

int main() {
    // Ejemplo de uso
    vector<Gasolinera> gasolineras = {{50, 30}, {100, 25}, {150, 35}, {200, 20}};
    int distancia_total = 250; // Distancia total del recorrido
    int capacidad_tanque = 100; // Capacidad del tanque de combustible

    algoritmoVoraz(gasolineras, distancia_total, capacidad_tanque);

    return 0;
}
