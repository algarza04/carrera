#include<bits/stdc++.h>
using namespace std;

struct Calle {
    int plaza1, plaza2, costo;
};

vector<int> padre, rango;
vector<Calle> calles;

int encontrar_conjunto(int v) {
    if (v == padre[v])
        return v;
    return padre[v] = encontrar_conjunto(padre[v]);
}

void crear_conjunto(int v) {
    padre[v] = v;
    rango[v] = 0;
}

void agregar_calle(int plaza1, int plaza2, int costo) {
    calles.push_back({plaza1, plaza2, costo});
}

void kruskal() {
    vector<bool> usada(calles.size(), false);
    for (int i = 0; i < calles.size(); i++) {
        int min_costo = INT_MAX;
        int min_calle = -1;
        for (int j = 0; j < calles.size(); j++) {
            if (!usada[j] && calles[j].costo < min_costo) {
                min_costo = calles[j].costo;
                min_calle = j;
            }
        }
        if (min_calle != -1) {
            int plaza1 = calles[min_calle].plaza1;
            int plaza2 = calles[min_calle].plaza2;
            if (encontrar_conjunto(plaza1) != encontrar_conjunto(plaza2)) {
                cout << plaza1 << " " << plaza2 << "\n";
                padre[encontrar_conjunto(plaza1)] = encontrar_conjunto(plaza2);
            }
            usada[min_calle] = true;
        }
    }
}

int main() {
    int n = 5; // número de plazas
    padre.resize(n);
    rango.resize(n);
    for (int i = 0; i < n; i++)
        crear_conjunto(i);

    // Agregar calles
    agregar_calle(1, 2, 2);
    agregar_calle(1, 3, 3);
    agregar_calle(2, 3, 1);
    agregar_calle(2, 4, 3);
    agregar_calle(3, 5, 4);
    agregar_calle(4, 5, 2);

    kruskal();
    return 0;
}





