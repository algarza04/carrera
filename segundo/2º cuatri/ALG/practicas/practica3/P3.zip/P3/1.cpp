#include <cstdlib>
#include <iostream>
#include <vector>

using namespace std;

unsigned int Emparejar(vector<vector<unsigned int>> &preferencia, vector<unsigned int> &almacen, unsigned int n);
bool esta(const vector<unsigned int> almacen, unsigned int esta);
void imprime(const vector<unsigned int> &almacen);
void imprimeMatriz(const vector<vector<unsigned int>> &preferencia, int n);

struct mejor {
    unsigned int num;
    unsigned int cantidad;
};

int main(int argc, char *argv[]) {
    int n = 0;
    unsigned int suma = 0;
    if (argc != 2 || atoi(argv[1]) <= 0 || atoi(argv[1]) % 2 == 1) {
        cerr << "No has introducido un número válido de argumentos, introduce un argumento con la cantidad de alumnos";
        exit(1);
    }
    n = atoi(argv[1]);
    const unsigned long int semilla = 99;
    vector<vector<unsigned int>> preferencia;
    vector<unsigned int> almacen;
    srand(semilla);

    preferencia.resize(n, vector<unsigned int>(n)); // Inicialización de las filas de preferencia

    for (unsigned int i = 0; i < n; i++) {
        for (unsigned int j = 0; j < n; j++)
            preferencia[i][j] = rand()%100 + 1; // Inicializamos el array con randoms del 1 al 100
    }
    
    imprimeMatriz(preferencia, n);

    suma = Emparejar(preferencia, almacen, n );
    
    
    imprime(almacen);
    cout << "La suma de la preferencia total es " << suma << endl;   
}

bool esta(const vector<unsigned int> almacen, unsigned int esta) {
    for (int i = 0; i < almacen.size(); i++)
        if (almacen[i] == esta)
            return true;
    return false;
}

unsigned int Emparejar(vector<vector<unsigned int>> &preferencia, vector<unsigned int> &almacen, unsigned int n) {
    mejor aux;
    unsigned int suma = 0;
    aux.num = 0;
    aux.cantidad = 0;
    unsigned int cantidad = 0;
    for (int i = 0; i < n; i++) {
        if (!esta(almacen, i+1)) {
            almacen.push_back(i+1);
            for (unsigned int j = 0; j < n; j++) {
                cantidad = preferencia[i][j] * preferencia[j][i];
                if ((i+1) != (j+1) && !esta(almacen, j+1) && cantidad > aux.cantidad) {
                    aux.num = j+1;
                    aux.cantidad = cantidad;
                }
            }
            suma += aux.cantidad;
            almacen.push_back(aux.num);
            aux.num = 0;
            aux.cantidad = 0;
        }
    }
    return suma;
}

void imprimeMatriz(const vector<vector<unsigned int>> &preferencia, int n){
	for (int i = 0; i < n; i++){
		cout << "|";
		for(int j=0; j < n; j ++){
			if(j==i)
				cout << " - |";	
			else
				cout << " " << preferencia[i][j] << " |";
		}
	cout << endl;
	}
}

void imprime(const vector<unsigned int> &almacen){
	for (int i = 0; i < almacen.size(); i+=2){
		for(int j=i; j < i+2; j ++)
			cout << almacen[j] << "  ";
		cout << endl;
	}		
}
