//Álvaro García Zafra
//mpicxx -std=c++11 -o filosofos filosofos.cpp 
//mpirun -oversubscribe -np 10 filosofos
// -----------------------------------------------------------------------------
//
// Sistemas concurrentes y Distribuidos.
// Práctica 3. Implementación de algoritmos distribuidos con MPI
//
// Archivo: filosofos-plantilla.cpp
// Implementación del problema de los filósofos (sin camarero).
// Plantilla para completar.
//
// Historial:
// Actualizado a C++11 en Septiembre de 2017
// -----------------------------------------------------------------------------


//una opción para solucionar el problema del bucle infinito sería hacer que uno de los filósofos coja primero el tenedor de la derecha antes que el de la iquierda, así siempre habrá alguno que pueda coger 2 tenedores y así podrá comer
#include <mpi.h>
#include <thread> // this_thread::sleep_for
#include <random> // dispositivos, generadores y distribuciones aleatorias
#include <chrono> // duraciones (duration), unidades de tiempo
#include <iostream>

using namespace std;
using namespace std::this_thread ;
using namespace std::chrono ;

const int
   num_filosofos = 5 ,              // número de filósofos 
   num_filo_ten  = 2*num_filosofos, // número de filósofos y tenedores 
   num_procesos  = num_filo_ten ;   // número de procesos total (por ahora solo hay filo y ten)

int etiq_solicitar = 0,
	 etiq_soltar = 1;

//**********************************************************************
// plantilla de función para generar un entero aleatorio uniformemente
// distribuido entre dos valores enteros, ambos incluidos
// (ambos tienen que ser dos constantes, conocidas en tiempo de compilación)
//----------------------------------------------------------------------

template< int min, int max > int aleatorio()
{
  static default_random_engine generador( (random_device())() );
  static uniform_int_distribution<int> distribucion_uniforme( min, max ) ;
  return distribucion_uniforme( generador );
}

// ---------------------------------------------------------------------

void funcion_filosofos( int id )
{
  int id_ten_izq = (id+1)              % num_filo_ten, //id. tenedor izq.
      id_ten_der = (id+num_filo_ten-1) % num_filo_ten, //id. tenedor der.
 		peticion;
  
  while ( true )
  {
    if ( id != 2 ){
    	cout <<"Filósofo " <<id/2 << " solicita ten. izq." <<id_ten_izq/2 <<endl;
    	MPI_Ssend(&peticion, 1, MPI_INT, id_ten_izq, etiq_solicitar, MPI_COMM_WORLD);
    	
		cout <<"Filósofo " <<id/2 <<" solicita ten. der." <<id_ten_der/2 <<endl;
    	MPI_Ssend(&peticion, 1, MPI_INT, id_ten_der, etiq_solicitar, MPI_COMM_WORLD);
    }
    else{
    	cout <<"Filósofo " <<id/2 <<" solicita ten. der." <<id_ten_der/2 <<endl;
    	MPI_Ssend(&peticion, 1, MPI_INT, id_ten_der, etiq_solicitar, MPI_COMM_WORLD);
    	
    	cout <<"Filósofo " <<id/2 << " solicita ten. izq." <<id_ten_izq/2 <<endl;
    	MPI_Ssend(&peticion, 1, MPI_INT, id_ten_izq, etiq_solicitar, MPI_COMM_WORLD);
    }

    cout <<"Filósofo " <<id/2 <<" comienza a comer" <<endl ;
    sleep_for( milliseconds( aleatorio<10,100>() ) );

    cout <<"Filósofo " <<id/2 <<" suelta ten. izq. " <<id_ten_izq/2 <<endl;
    	MPI_Ssend(&peticion, 1, MPI_INT, id_ten_izq, etiq_soltar, MPI_COMM_WORLD);	
	
    cout<< "Filósofo " <<id/2 <<" suelta ten. der. " <<id_ten_der/2 <<endl;
    MPI_Ssend(&peticion, 1, MPI_INT, id_ten_der, etiq_soltar, MPI_COMM_WORLD);	

    cout << "Filosofo " << id/2 << " comienza a pensar" << endl;
    sleep_for( milliseconds( aleatorio<10,100>() ) );
 }
}
// ---------------------------------------------------------------------

void funcion_tenedores( int id )
{
  int valor, id_filosofo ;  // valor recibido, identificador del filósofo
  MPI_Status estado ;       // metadatos de las dos recepciones

  while ( true )
  {
     MPI_Recv(&valor, 1, MPI_INT, MPI_ANY_SOURCE, etiq_solicitar, MPI_COMM_WORLD, &estado);

     id_filosofo = estado.MPI_SOURCE;
     
     cout <<"Ten. " <<id/2 <<" ha sido cogido por filo. " <<id_filosofo/2 <<endl;

     MPI_Recv(&valor, 1, MPI_INT, id_filosofo, etiq_soltar, MPI_COMM_WORLD, &estado);
     cout <<"Ten. "<< id/2<< " ha sido liberado por filo. " <<id_filosofo/2 <<endl ;
  }
}
// ---------------------------------------------------------------------

int main( int argc, char** argv )
{
   int id_propio, num_procesos_actual ;

   MPI_Init( &argc, &argv );
   MPI_Comm_rank( MPI_COMM_WORLD, &id_propio );
   MPI_Comm_size( MPI_COMM_WORLD, &num_procesos_actual );


   if ( num_procesos == num_procesos_actual )
   {
      // ejecutar la función correspondiente a 'id_propio'
      if ( id_propio % 2 == 0 )          // si es par
         funcion_filosofos( id_propio ); //   es un filósofo
      else                               // si es impar
         funcion_tenedores( id_propio ); //   es un tenedor
   }
   else
   {
      if ( id_propio == 0 ) // solo el primero escribe error, indep. del rol
      { cout << "el número de procesos esperados es:    " << num_procesos << endl
             << "el número de procesos en ejecución es: " << num_procesos_actual << endl
             << "(programa abortado)" << endl ;
      }
   }

   MPI_Finalize( );
   return 0;
}

// ---------------------------------------------------------------------
