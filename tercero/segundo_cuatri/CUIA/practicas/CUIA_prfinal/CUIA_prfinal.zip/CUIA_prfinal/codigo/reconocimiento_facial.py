import cv2
import os
import json
import numpy as np
import speech_recognition as sr
import time

DATASET_DIR = "rostros"
USUARIOS_JSON = "usuarios.json"
RECONOCEDOR_PATH = "modelo_lbph.xml"
DETECTOR_PATH = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"

def entrenar_modelo():
    etiquetas = []
    imagenes = []
    usuarios = cargar_usuarios()

    for usuario in usuarios:
        id_usuario = usuario["id"]
        ruta = os.path.join(DATASET_DIR, f"{id_usuario}")
        if not os.path.exists(ruta):
            continue
        for archivo in os.listdir(ruta):
            img_path = os.path.join(ruta, archivo)
            img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
            if img is not None:
                imagenes.append(img)
                etiquetas.append(id_usuario)

    if len(imagenes) == 0:
        return None

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.train(imagenes, np.array(etiquetas))
    recognizer.save(RECONOCEDOR_PATH)
    return recognizer

def cargar_modelo():
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    if os.path.exists(RECONOCEDOR_PATH):
        recognizer.read(RECONOCEDOR_PATH)
        return recognizer
    return entrenar_modelo()

def cargar_usuarios():
    if os.path.exists("usuarios.json"):
        with open("usuarios.json", "r") as f:
            return json.load(f)
    return []

def guardar_usuarios(lista_usuarios):
    with open("usuarios.json", "w") as f:
        json.dump(lista_usuarios, f, indent=4)

def capturar_nombre_por_voz():
    recognizer = sr.Recognizer()
    mic = sr.Microphone()

    with mic as source:
        print("Por favor, di tu nombre...")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)

    try:
        nombre = recognizer.recognize_google(audio, language="es-ES")
        print(f"Nombre reconocido: {nombre}")
        return nombre
    except sr.UnknownValueError:
        print("No entendí tu nombre. Intenta de nuevo.")
        return capturar_nombre_por_voz()
    except sr.RequestError as e:
        print(f"Error con el servicio de voz: {e}")
        return None

def registrar_usuario(nombre):
    usuarios = cargar_usuarios()
    id_nuevo = max([u["id"] for u in usuarios], default=0) + 1
    nuevo_usuario = {
        "nombre": nombre,
        "id": id_nuevo,
        "favoritas": []
    }
    usuarios.append(nuevo_usuario)
    guardar_usuarios(usuarios)
    capturar_rostros(id_nuevo)
    entrenar_modelo()
    return nuevo_usuario

def capturar_rostros(id_usuario):
    os.makedirs(f"{DATASET_DIR}/{id_usuario}", exist_ok=True)
    cam = cv2.VideoCapture(0)
    detector = cv2.CascadeClassifier(DETECTOR_PATH)
    count = 0

    while True:
        ret, frame = cam.read()
        if not ret:
            break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        rostros = detector.detectMultiScale(gray, 1.3, 5)

        for (x, y, w, h) in rostros:
            rostro = gray[y:y+h, x:x+w]
            cv2.imwrite(f"{DATASET_DIR}/{id_usuario}/rostro_{count}.jpg", rostro)
            count += 1
            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)

        cv2.imshow("Registro de rostro (ESC para salir)", frame)
        if cv2.waitKey(1) & 0xFF == 27 or count >= 20:
            break

    cam.release()
    cv2.destroyAllWindows()

def identificar_o_registrar():
    usuarios = cargar_usuarios()
    recognizer = cargar_modelo()
    
    if recognizer is None:
        print("No hay modelo entrenado. Se necesita registrar al primer usuario.")
        nombre = capturar_nombre_por_voz()
        if nombre:
            return registrar_usuario(nombre)
        return None

    cam = cv2.VideoCapture(0)
    detector = cv2.CascadeClassifier(DETECTOR_PATH)
    identificado = False
    usuario = None

    print("Escaneando rostro...")
    tiempo_inicio = time.time()
    tiempo_limite = 10  # segundos

    while True:
        ret, frame = cam.read()
        if not ret:
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        rostros = detector.detectMultiScale(gray, 1.3, 5)

        for (x, y, w, h) in rostros:
            rostro = gray[y:y+h, x:x+w]
            id_predicho, conf = recognizer.predict(rostro)

            if conf < 70:
                usuario = next((u for u in usuarios if u["id"] == id_predicho), None)
                if usuario:
                    identificado = True
                    cv2.putText(frame, f"{usuario['nombre']}", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
                    break

            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        cv2.imshow("Reconocimiento Facial", frame)

        if identificado:
            break

        # Si el tiempo se agota sin identificación, salir del bucle para registrar
        if time.time() - tiempo_inicio > tiempo_limite:
            print("Tiempo de reconocimiento agotado.")
            break

        if cv2.waitKey(1) & 0xFF == 27:  # Opción de salida manual opcional
            break

    cam.release()
    cv2.destroyAllWindows()

    if identificado:
        print(f"¡Hola {usuario['nombre']}! Bienvenido.")
        return usuario
    else:
        print("No se reconoció el rostro. Registrando nuevo usuario...")
        nombre = capturar_nombre_por_voz()
        if nombre:
            return registrar_usuario(nombre)
        return None
    
def actualizar_favoritas(nombre_usuario, nuevas_favoritas):
    usuarios = cargar_usuarios()
    for u in usuarios:
        if u["nombre"].lower() == nombre_usuario.lower():
            u["favoritas"] = nuevas_favoritas
            break
    guardar_usuarios(usuarios)
