import cv2
import numpy as np
import cuia
import speech_recognition as sr
import threading
import estado_de_juego
import sys
import reconocimiento_facial

# Variables globales
id_jugador = 1
marcadores_seleccionados = 0
tropas = np.empty((4, 4))
tropa_delantera1 = 0
tropa_delantera2 = 2
exit_flag = False
salir = False
perdedor = [False, False]

imagen = cv2.cvtColor(cv2.imread("imagenes/negro.png"), cv2.COLOR_BGR2BGRA)
imagenes = [imagen, imagen, imagen, imagen]

usuario = reconocimiento_facial.identificar_o_registrar()

# --- VOZ ---
def voz_callback(recognizer, audio):
    global exit_flag, id_jugador, marcadores_seleccionados, imagenes, salir, tropa_delantera1, tropa_delantera2, perdedor, tropas, usuario

    try:
        texto = recognizer.recognize_google(audio, language="es-ES")
        print("Dijiste:", texto)

        # mientras que no haya 4 tropas seleccionadas
        if not salir:
            # Cargar favoritas por comando
            if "cargar lista de favoritos" in texto.lower():
                if usuario and "favoritas" in usuario:
                    for i, carta in enumerate(usuario["favoritas"]):
                        if i >= 4:
                            break
                        if carta == "dragon_fuego":
                            imagenes[i] = cv2.cvtColor(cv2.imread("imagenes/dragon_fuego.jpg"), cv2.COLOR_BGR2BGRA)
                            estado_de_juego.crear_tropa(i, 0, tropas)
                        elif carta == "dragon_agua":
                            imagenes[i] = cv2.cvtColor(cv2.imread("imagenes/dragon_agua.jpg"), cv2.COLOR_BGR2BGRA)
                            estado_de_juego.crear_tropa(i, 1, tropas)
                        elif carta == "golem":
                            imagenes[i] = cv2.cvtColor(cv2.imread("imagenes/golem.png"), cv2.COLOR_BGR2BGRA)
                            estado_de_juego.crear_tropa(i, 2, tropas)
                        elif carta == "erizo":
                            imagenes[i] = cv2.cvtColor(cv2.imread("imagenes/erizo.png"), cv2.COLOR_BGR2BGRA)
                            estado_de_juego.crear_tropa(i, 3, tropas)
                    marcadores_seleccionados = len(usuario["favoritas"])
                    if marcadores_seleccionados >= 4:
                        salir = True
                    print("Favoritas cargadas.")
                else:
                    print("No hay favoritas guardadas para este usuario.")
                return

            # Modificar lista de favoritas por voz
            elif "modificar lista de favoritos" in texto.lower():
                nuevas_favoritas = []
                print("Dime las cartas que quieres guardar como favoritas (máximo 4). Di 'fin' para terminar antes de tiempo.")
                with sr.Microphone() as source:
                    while len(nuevas_favoritas) < 4:
                        try:
                            print("Escuchando carta...")
                            audio = recognizer.listen(source, timeout=5)
                            carta = recognizer.recognize_google(audio, language="es-ES").lower()
                            print(f"Detectado: {carta}")

                            if "fin" in carta:
                                break
                            elif "dragón de fuego" in carta:
                                nuevas_favoritas.append("dragon_fuego")
                            elif "dragón de agua" in carta:
                                nuevas_favoritas.append("dragon_agua")
                            elif "golem" in carta:
                                nuevas_favoritas.append("golem")
                            elif "erizo" in carta:
                                nuevas_favoritas.append("erizo")
                            else:
                                print("Carta no reconocida.")
                        except sr.UnknownValueError:
                            print("No entendí. Repite por favor.")
                        except sr.WaitTimeoutError:
                            print("No se detectó voz. Intenta de nuevo.")

                if nuevas_favoritas:
                    reconocimiento_facial.actualizar_favoritas(usuario["nombre"], nuevas_favoritas)
                    
                    # Refrescar el objeto usuario desde JSON actualizado
                    for u in reconocimiento_facial.cargar_usuarios():
                        if u["nombre"].lower() == usuario["nombre"].lower():
                            usuario = u
                            break

                    print(f"Lista de favoritas actualizada: {usuario['favoritas']}")
                else:
                    print("No se añadió ninguna carta.")
                return

            # Añadir tropas
            elif "añadir dragón de fuego" in texto.lower():
                if marcadores_seleccionados < 4:
                    imagenes[marcadores_seleccionados] = cv2.cvtColor(cv2.imread("imagenes/dragon_fuego.jpg"), cv2.COLOR_BGR2BGRA)
                    estado_de_juego.crear_tropa(marcadores_seleccionados, 0, tropas)
                    marcadores_seleccionados += 1
                    print("Se añadió un Dragón de Fuego.")
                else:
                    print("Ya hay 4 tropas.")
            elif "añadir dragón de agua" in texto.lower():
                if marcadores_seleccionados < 4:
                    imagenes[marcadores_seleccionados] = cv2.cvtColor(cv2.imread("imagenes/dragon_agua.jpg"), cv2.COLOR_BGR2BGRA)
                    estado_de_juego.crear_tropa(marcadores_seleccionados, 1, tropas)
                    marcadores_seleccionados += 1
                    print("Se añadió un Dragón de Agua.")
                else:
                    print("Ya hay 4 tropas.")
            elif "añadir golem" in texto.lower():
                if marcadores_seleccionados < 4:
                    imagenes[marcadores_seleccionados] = cv2.cvtColor(cv2.imread("imagenes/golem.png"), cv2.COLOR_BGR2BGRA)
                    estado_de_juego.crear_tropa(marcadores_seleccionados, 2, tropas)
                    marcadores_seleccionados += 1
                    print("Se añadió un Gólem.")
                else:
                    print("Ya hay 4 tropas.")
            elif "añadir erizo" in texto.lower():
                if marcadores_seleccionados < 4:
                    imagenes[marcadores_seleccionados] = cv2.cvtColor(cv2.imread("imagenes/erizo.png"), cv2.COLOR_BGR2BGRA)
                    estado_de_juego.crear_tropa(marcadores_seleccionados, 3, tropas)
                    marcadores_seleccionados += 1
                    print("Se añadió un Erizo.")
                else:
                    print("Ya hay 4 tropas.")
            else:
                print("Comando no válido o no permitido en esta fase.")

            print(f"Marcadores seleccionados: {marcadores_seleccionados}/4")
            if marcadores_seleccionados >= 4:
                salir = True
                print("Tropas completas. Comienza la batalla.")
            return

        # ETAPA 2: Una vez están los marcadores seleccionados comienza la batalla
        tropa_trasera1 = 1 if tropa_delantera1 == 0 else 0
        tropa_trasera2 = 3 if tropa_delantera2 == 2 else 2

        # Si la tropa delantera muere se cambia por la otra
        if not estado_de_juego.tropa_con_vida(tropa_delantera1, tropas):
            tropa_delantera1 = estado_de_juego.cambiar_tropa_delantera(tropa_delantera1, 1, tropas)
        if not estado_de_juego.tropa_con_vida(tropa_delantera2, tropas):
            tropa_delantera2 = estado_de_juego.cambiar_tropa_delantera(tropa_delantera2, 2, tropas)

        perdedor[0] = estado_de_juego.jugador_sin_tropas(1, tropas)
        perdedor[1] = estado_de_juego.jugador_sin_tropas(2, tropas)

        if perdedor[0] or perdedor[1]:
            if perdedor[0]:
                print("¡El Jugador 1 ha perdido! ¡El Jugador 2 gana!")
                exit_flag = True
            elif perdedor[1]:
                print("¡El Jugador 2 ha perdido! ¡El Jugador 1 gana!")
                exit_flag = True
            sys.exit() # FIN

        # Proceso de los combates
        # cambio de tropa
        if "cambiar tropa delantera" in texto.lower():
            if id_jugador == 1:
                tropa_antes_cambio = tropa_delantera1
                tropa_delantera1 = estado_de_juego.cambiar_tropa_delantera(tropa_delantera1, id_jugador, tropas)
                if tropa_delantera1 is None: # ambas tropas muertas
                    print("¡No te quedan tropas para cambiar!")
                elif tropa_antes_cambio != tropa_delantera1: # Cambio de tropa delantera
                    print(f"Jugador 1 cambió la tropa delantera a {tropa_delantera1}.")
                    id_jugador = 2
                else:
                    print("No se pudo cambiar la tropa delantera (la otra tropa podría estar sin vida o ya es la delantera).")
            else:
                tropa_antes_cambio = tropa_delantera2
                tropa_delantera2 = estado_de_juego.cambiar_tropa_delantera(tropa_delantera2, id_jugador, tropas)
                if tropa_delantera2 is None: # Both troops dead
                    print("¡No te quedan tropas para cambiar!")
                elif tropa_antes_cambio != tropa_delantera2: # Successful swap
                    print(f"Jugador 2 cambió la tropa delantera a {tropa_delantera2}.")
                    id_jugador = 1
                else:
                    print("No se pudo cambiar la tropa delantera (la otra tropa podría estar sin vida o ya es la delantera).")
        elif "atacar con la primera tropa" in texto.lower():
            if id_jugador == 1:
                if estado_de_juego.tropa_con_vida(tropa_delantera1, tropas):
                    print(f"Jugador 1 ataca con su tropa delantera (ID: {tropa_delantera1}).")
                    estado_de_juego.atacar(tropa_delantera1, tropa_delantera1, tropa_delantera2, id_jugador, tropas)
                    id_jugador = 2
                else:
                    print("No se puede atacar con la tropa delantera porque no tiene vida.")
            else:
                if estado_de_juego.tropa_con_vida(tropa_delantera2, tropas):
                    print(f"Jugador 2 ataca con su tropa delantera (ID: {tropa_delantera2}).")
                    estado_de_juego.atacar(tropa_delantera2, tropa_delantera2, tropa_delantera1, id_jugador, tropas)
                    id_jugador = 1
                else:
                    print("No se puede atacar con la tropa delantera porque no tiene vida.")
        elif "atacar con la segunda tropa" in texto.lower():
            if id_jugador == 1:
                if estado_de_juego.tropa_con_vida(tropa_trasera1, tropas):
                    print(f"Jugador 1 ataca con su tropa trasera (ID: {tropa_trasera1}).")
                    estado_de_juego.atacar(tropa_trasera1, tropa_delantera1, tropa_delantera2, id_jugador, tropas)
                    id_jugador = 2
                else:
                    print("No se puede atacar con la tropa trasera porque no tiene vida.")
            else:
                if estado_de_juego.tropa_con_vida(tropa_trasera2, tropas):
                    print(f"Jugador 2 ataca con su tropa trasera (ID: {tropa_trasera2}).")
                    estado_de_juego.atacar(tropa_trasera2, tropa_delantera2, tropa_delantera1, id_jugador, tropas)
                    id_jugador = 1
                else:
                    print("No se puede atacar con la tropa trasera porque no tiene vida.")
        elif "me rindo" in texto.lower():
            if id_jugador == 1:
                perdedor[0] = True
                exit_flag = True 
                print("El Jugador 1 se ha rendido. ¡El Jugador 2 gana!")
            else: 
                perdedor[1] = True
                print("El Jugador 2 se ha rendido. ¡El Jugador 1 gana!")
                exit_flag = True
            sys.exit() 
        else:
            print("Comando no reconocido. Intenta 'atacar con la primera tropa', 'atacar con la segunda tropa', 'cambiar tropa delantera', o 'me rindo'.")

        # After any action, re-check for game over conditions
        perdedor[0] = estado_de_juego.jugador_sin_tropas(1, tropas)
        perdedor[1] = estado_de_juego.jugador_sin_tropas(2, tropas)

    except sr.UnknownValueError:
        print("No se entendió el audio.")
    except sr.RequestError as e:
        print(f"Error con el servicio de voz: {e}")
        
# Escucha en segundo plano
r = sr.Recognizer()
m = sr.Microphone()
with m as source:
    r.adjust_for_ambient_noise(source)
    print("Micrófono calibrado. Escuchando...")
stop_listening = r.listen_in_background(m, voz_callback)

diccionario = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_5X5_50)
detector = cv2.aruco.ArucoDetector(diccionario)

cam = 0
bk = cuia.bestBackend(cam)
webcam = cv2.VideoCapture(cam, bk)
ancho = int(webcam.get(cv2.CAP_PROP_FRAME_WIDTH))
alto = int(webcam.get(cv2.CAP_PROP_FRAME_HEIGHT))
webcam.release()

# Calibración
try:
    import camara
    cameraMatrix = camara.cameraMatrix
    distCoeffs = camara.distCoeffs
except ImportError:
    cameraMatrix = np.array([
        [1000, 0, ancho / 2],
        [0, 1000, alto / 2],
        [0, 0, 1]
    ])
    distCoeffs = np.zeros((5, 1))

ar = cuia.myVideo(cam, bk)

def origen(TAM):
    return(np.array([[-TAM/2.0, -TAM/2.0, 0.0],
                     [-TAM/2.0,  TAM/2.0, 0.0],
                     [ TAM/2.0,  TAM/2.0, 0.0],
                     [ TAM/2.0, -TAM/2.0, 0.0]]))

def proyeccion(puntos, rvec, tvec, cameraMatrix, distCoeffs):
    if isinstance(puntos, list):
        return(proyeccion(np.array(puntos, dtype=np.float32), rvec, tvec, cameraMatrix, distCoeffs))
    if isinstance(puntos, np.ndarray):
        if puntos.ndim == 1 and puntos.size == 3:
            res, _ = cv2.projectPoints(puntos.astype(np.float32), rvec, tvec, cameraMatrix, distCoeffs)
            return(res[0][0].astype(int))
        if puntos.ndim > 1:
            aux = proyeccion(puntos[0], rvec, tvec, cameraMatrix, distCoeffs)
            aux = np.expand_dims(aux, axis=0)
            for p in puntos[1:]:
                aux = np.append(aux, [proyeccion(p, rvec, tvec, cameraMatrix, distCoeffs)], axis=0)
            return(np.array(aux))

def variasimagenes(frame):
    framebgra = cv2.cvtColor(frame, cv2.COLOR_BGR2BGRA)
    hframe, wframe, _ = frame.shape
    tam = 0.1
    bboxs, ids, _ = detector.detectMarkers(frame)
    if ids is not None:
        res = framebgra
        for i in range(len(ids)):
            ret, rvec, tvec = cv2.solvePnP(origen(tam), bboxs[i], cameraMatrix, distCoeffs)
            if ret:
                id_marcador = ids[i][0]

                if id_marcador < len(imagenes):
                    imagen = imagenes[id_marcador]
                    tropa_vida = tropas[id_marcador][0]

                    # Convertir a gris si está muerta
                    if tropa_vida <= 0:
                        gris = cv2.cvtColor(imagen[:, :, :3], cv2.COLOR_BGR2GRAY)
                        gris_color = cv2.cvtColor(gris, cv2.COLOR_GRAY2BGRA)
                        gris_color[:, :, 3] = imagen[:, :, 3]
                        imagen = gris_color

                    # Proyección de imagen al marcador
                    h, w, _ = imagen.shape
                    desde = np.array([[0, 0], [w, 0], [w, h], [0, h]])
                    hasta = proyeccion(origen(tam), rvec, tvec, cameraMatrix, distCoeffs)
                    M = cv2.getPerspectiveTransform(np.float32(desde), np.float32(hasta))
                    warp = cv2.warpPerspective(imagen, M, dsize=(wframe, hframe))
                    res = cuia.alphaBlending(warp, res)

                    # ----------- TEXTO FLOTANTE 3D -----------
                    posicion_3D_texto = np.array([[0, 0, -0.05]])
                    punto_2D, _ = cv2.projectPoints(posicion_3D_texto, rvec, tvec, cameraMatrix, distCoeffs)
                    x, y = punto_2D[0][0].astype(int)

                    if tropa_vida > 0:
                        texto = f"{int(tropa_vida)} HP"
                        color_texto = (255, 255, 0, 255)
                    else:
                        texto = "MUERTA"
                        color_texto = (0, 0, 255, 255) 

                    # Mostrar texto
                    cv2.putText(res, texto, (x - 30, y), cv2.FONT_HERSHEY_SIMPLEX,
                                0.8, color_texto, 2, cv2.LINE_AA)
    else:
        res = frame


    # Mostrar vida como texto en la esquina superior izquierda
    if perdedor[0]:
        cv2.putText(res, f"Ha ganado el jugador : 2", (10, 200), cv2.FONT_HERSHEY_SIMPLEX, 1, (200,128,128), 2)
    elif perdedor[1]:
        cv2.putText(res, f"Ha ganado el jugador : 1", (10, 200), cv2.FONT_HERSHEY_SIMPLEX, 1, (200,128,128), 2)
    elif perdedor[0] and perdedor[1]:
        cv2.putText(res, f"Ha habido un empate", (10, 200), cv2.FONT_HERSHEY_SIMPLEX, 1, (200,128,128), 2)
    else:
        cv2.putText(res, f"Jugador 1 tropa al frente: {tropa_delantera1}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (200,128,128), 2)
        cv2.putText(res, f"Jugador 2 tropa al frente: {tropa_delantera2}", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 1, (200,128,128), 2)
        cv2.putText(res, f"Turno: {id_jugador}", (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 1, (200,128,128), 2)

    return res

ar.process = variasimagenes

try:
    ar.play("CUIA Álvaro García", key=ord(' '))
    while not exit_flag:
        continue 
finally:
    stop_listening(wait_for_stop=False)
    ar.release()
