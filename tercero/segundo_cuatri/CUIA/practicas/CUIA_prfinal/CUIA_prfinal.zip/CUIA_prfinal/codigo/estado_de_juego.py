def crear_tropa(id, tipo_tropa, tropas):
    #dragon fuego
    if tipo_tropa == 0:
        tropas[id][0] = 650
        tropas[id][1] = 250
        tropas[id][2] = 100
        tropas[id][3] = tipo_tropa
    #dragon agua
    if tipo_tropa == 1:
        tropas[id][0] = 850
        tropas[id][1] = 200
        tropas[id][2] = 50
        tropas[id][3] = tipo_tropa
    #golem
    if tipo_tropa == 2:
        tropas[id][0] = 1000
        tropas[id][1] = 150
        tropas[id][2] = 0.8
        tropas[id][3] = tipo_tropa
    #erizo
    if tipo_tropa == 3:
        tropas[id][0] = 500
        tropas[id][1] = 200
        tropas[id][2] = 200
        tropas[id][3] = tipo_tropa

def tropa_con_vida(id, tropas):
    if tropas[id][0] > 0:
        return True
    else:
        return False
    
def atacar(id, tropa_delantera_ataque, tropa_delantera_defensa, jugador_activo, tropas):
    # Determine the defending player based on the attacking player
    if jugador_activo == 1: # Player 1 is attacking, so Player 2 is defending
        jugador_defensor = 2
    else: # Player 2 is attacking, so Player 1 is defending
        jugador_defensor = 1

    if id == tropa_delantera_ataque : # Attacking with the front troop (special ability active)
        if comprobar_golem(jugador_defensor, tropas):
            defensa_extra = 0.8
        else:
            defensa_extra = 1

        if comprobar_erizo(jugador_defensor, tropas):
            daño_recibido = 200
        else:
            daño_recibido = 0
        
        # Check if the defending front troop is alive before applying damage
        if tropa_con_vida(tropa_delantera_defensa, tropas):
            # Apply normal attack damage
            tropas[tropa_delantera_defensa][0] -= tropas[id][1] * defensa_extra
        else:
            # If the front troop is dead, the damage is effectively lost for a direct attack
            pass # Or you could implement logic to hit the back troop if present, but current rules imply direct to front

        if tropas[id][3] == 0: # Dragon Fuego
            # Apply special area damage if attacking with front troop
            # Ensure enemy troops are alive before applying area damage
            if jugador_activo == 1: # Attacking P2's troops
                if tropa_con_vida(2, tropas):
                    tropas[2][0] -= tropas[id][2] * defensa_extra
                if tropa_con_vida(3, tropas):
                    tropas[3][0] -= tropas[id][2] * defensa_extra
            else: # Attacking P1's troops
                if tropa_con_vida(0, tropas):
                    tropas[0][0] -= tropas[id][2] * defensa_extra
                if tropa_con_vida(1, tropas):
                    tropas[1][0] -= tropas[id][2] * defensa_extra
            
            # Apply self-damage from Erizo if present
            tropas[id][0] -= daño_recibido

        if tropas[id][3] == 1: # Dragon Agua
            # Apply special healing if attacking with front troop
            # Ensure allied troops are alive before healing
            if jugador_activo == 1: # Healing P1's troops
                if tropa_con_vida(0, tropas):
                    tropas[0][0] += tropas[id][2]
                if tropa_con_vida(1, tropas):
                    tropas[1][0] += tropas[id][2]
            else: # Healing P2's troops
                if tropa_con_vida(2, tropas):
                    tropas[2][0] += tropas[id][2]
                if tropa_con_vida(3, tropas):
                    tropas[3][0] += tropas[id][2]

            # Apply self-damage from Erizo if present
            tropas[id][0] -= daño_recibido

        if tropas[id][3] == 2: # Golem
            # Golem's damage reduction is handled by defensa_extra
            # Apply self-damage from Erizo if present
            tropas[id][0] -= daño_recibido

        if tropas[id][3] == 3: # Erizo
            # Erizo's retaliation is handled by daño_recibido
            # Apply self-damage from Erizo if present
            tropas[id][0] -= daño_recibido
        
    else: # Attacking with a back troop (no special ability)
        if comprobar_golem(jugador_defensor, tropas):
            defensa_extra = 0.8
        else:
            defensa_extra = 1

        if comprobar_erizo(jugador_defensor, tropas):
            daño_recibido = 200
        else:
            daño_recibido = 0

        # Check if the defending front troop is alive before applying damage
        if tropa_con_vida(tropa_delantera_defensa, tropas):
            tropas[tropa_delantera_defensa][0] -= tropas[id][1] * defensa_extra
        else:
            pass # Damage lost if front troop is dead

        # Apply self-damage from Erizo if present (even from back-line attack)
        tropas[id][0] -= daño_recibido

    return tropas

def comprobar_golem(jugador_activo, tropas):
    # Checks if the active player (who is being attacked) has a Golem
    if jugador_activo == 1: # Check P1's troops (indices 0 and 1)
        if tropa_con_vida(0, tropas) and tropas[0][3] == 2:
            return True
        if tropa_con_vida(1, tropas) and tropas[1][3] == 2:
            return True
    else: # Check P2's troops (indices 2 and 3)
        if tropa_con_vida(2, tropas) and tropas[2][3] == 2:
            return True
        if tropa_con_vida(3, tropas) and tropas[3][3] == 2:
            return True
    return False

def comprobar_erizo(jugador_activo, tropas):
    # Checks if the active player (who is being attacked) has an Erizo
    if jugador_activo == 1: # Check P1's troops (indices 0 and 1)
        if tropa_con_vida(0, tropas) and tropas[0][3] == 3:
            return True
        if tropa_con_vida(1, tropas) and tropas[1][3] == 3:
            return True
    else: # Check P2's troops (indices 2 and 3)
        if tropa_con_vida(2, tropas) and tropas[2][3] == 3:
            return True
        if tropa_con_vida(3, tropas) and tropas[3][3] == 3:
            return True
    return False

def cambiar_tropa_delantera(tropa_delantera, id_jugador, tropas):
    # Check if the current front troop is still alive
    if tropa_con_vida(tropa_delantera, tropas):
        # If the current front troop is alive, we try to swap with the other troop
        if id_jugador == 1: # Player 1's troops are at index 0 and 1
            if tropa_delantera == 0:
                if tropa_con_vida(1, tropas):
                    return 1 # Swap 0 to 1
                else:
                    return 0 # Cannot swap, 1 is dead, keep 0
            elif tropa_delantera == 1:
                if tropa_con_vida(0, tropas):
                    return 0 # Swap 1 to 0
                else:
                    return 1 # Cannot swap, 0 is dead, keep 1
        elif id_jugador == 2: # Player 2's troops are at index 2 and 3
            if tropa_delantera == 2:
                if tropa_con_vida(3, tropas):
                    return 3 # Swap 2 to 3
                else:
                    return 2 # Cannot swap, 3 is dead, keep 2
            elif tropa_delantera == 3:
                if tropa_con_vida(2, tropas):
                    return 2 # Swap 3 to 2
                else:
                    return 3 # Cannot swap, 2 is dead, keep 3
    else:
        # If the current front troop is dead, automatically switch to the other if it's alive
        if id_jugador == 1:
            if tropa_con_vida(0, tropas):
                return 0
            elif tropa_con_vida(1, tropas):
                return 1
            else:
                return None # Both troops are dead for this player
        elif id_jugador == 2:
            if tropa_con_vida(2, tropas):
                return 2
            elif tropa_con_vida(3, tropas):
                return 3
            else:
                return None # Both troops are dead for this player
    return tropa_delantera # If no valid swap or existing front troop is dead

def jugador_sin_tropas(id_jugador, tropas):
    if id_jugador == 1:
        return not tropa_con_vida(0, tropas) and not tropa_con_vida(1, tropas)
    elif id_jugador == 2:
        return not tropa_con_vida(2, tropas) and not tropa_con_vida(3, tropas)
    return False
