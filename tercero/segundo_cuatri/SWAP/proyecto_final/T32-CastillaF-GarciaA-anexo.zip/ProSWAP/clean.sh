#!/bin/bash

echo "Eliminando todos los contenedores y redes..."

# Detener y eliminar todos los contenedores
docker compose down -v

echo "Limpieza completada."
