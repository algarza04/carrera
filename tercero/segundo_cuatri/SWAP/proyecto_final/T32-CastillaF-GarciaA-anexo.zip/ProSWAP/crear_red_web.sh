#!/bin/bash

NETWORK_NAME="red_web"
SUBNET="192.168.10.0/24"

# Verificar si la red ya existe
if docker network ls --format '{{.Name}}' | grep -wq "$NETWORK_NAME"; then
    echo "La red '$NETWORK_NAME' ya existe. No se hace nada."
else
    if docker network create \
        --driver=bridge \
        --subnet="$SUBNET" \
        "$NETWORK_NAME"; then
        echo "Red '$NETWORK_NAME' creada con éxito."
    else
        echo "Error: no se pudo crear la red '$NETWORK_NAME'."
        exit 1
    fi
fi
