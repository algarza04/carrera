#!/bin/bash

echo "Iniciando despliegue de contenedores..."

# Bajar los contenedores en caso de que estén corriendo
docker compose down

# Construir y levantar los contenedores en segundo plano
docker compose up --build -d

echo "Contenedores desplegados exitosamente."

# Mostrar los contenedores activos
docker ps
