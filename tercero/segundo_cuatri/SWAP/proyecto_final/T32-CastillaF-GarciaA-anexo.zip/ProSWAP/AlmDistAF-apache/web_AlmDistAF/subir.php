<?php
$contenedor = gethostname();
$dir_fisico = '/var/www/html/archivos/';
$dir_web = '/archivos/';

echo "Servidor actual: " . $contenedor . "<br>";

if (!is_dir($dir_fisico)) {
    mkdir($dir_fisico, 0777, true);
}

if ($_FILES['archivo']['error'] !== UPLOAD_ERR_OK) {
    echo "Error en la subida: Código " . $_FILES['archivo']['error'] . "<br>";
    exit;
}

$fichero_subido = $dir_fisico . basename($_FILES['archivo']['name']);

if (move_uploaded_file($_FILES['archivo']['tmp_name'], $fichero_subido)) {
    echo "Archivo subido correctamente.<br>";

    $servername = "mysql";
    $username = "archivos_user";
    $password = "archivos_pass";
    $dbname = "archivos_db";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    $nombreArchivo = $conn->real_escape_string(basename($_FILES['archivo']['name']));
    $rutaArchivo = $conn->real_escape_string($dir_web . basename($_FILES['archivo']['name']));
    $nombreContenedor = $conn->real_escape_string($contenedor);

    $sql = "INSERT INTO archivos (nombre, ruta, contenedor) VALUES ('$nombreArchivo', '$rutaArchivo', '$nombreContenedor')";

    if ($conn->query($sql) === TRUE) {
        echo "Registro guardado en base de datos.<br>";
    } else {
        echo "Error al guardar registro: " . $conn->error . "<br>";
    }

    $conn->close();
} else {
    echo "Error al mover el archivo.<br>";
}

echo '<p><a href="index.php">Volver al formulario</a></p>';
?>

