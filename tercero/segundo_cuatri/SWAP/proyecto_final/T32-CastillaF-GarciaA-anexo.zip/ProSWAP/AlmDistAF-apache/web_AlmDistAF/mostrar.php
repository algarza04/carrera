<?php
$servername = "mysql";
$username = "archivos_user";
$password = "archivos_pass";
$dbname = "archivos_db";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Comprobar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$sql = "SELECT nombre, ruta, contenedor, fecha_subida FROM archivos ORDER BY fecha_subida DESC";
$result = $conn->query($sql);

echo "<h1>Archivos Subidos</h1>";
echo "<table border='1' cellpadding='5'><tr><th>Nombre</th><th>Ruta</th><th>Contenedor</th><th>Fecha de subida</th></tr>";

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . htmlspecialchars($row["nombre"]) . "</td>
                <td>" . htmlspecialchars($row["ruta"]) . "</td>
                <td>" . htmlspecialchars($row["contenedor"]) . "</td>
                <td>" . $row["fecha_subida"] . "</td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='4'>No hay archivos subidos aún.</td></tr>";
}
echo "</table>";

$conn->close();

echo '<p><a href="index.php">Volver</a></p>';
?>

