<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Subir archivo</title>
</head>
<body>
    <h2>Subir un archivo</h2>
    <form action="subir.php" method="post" enctype="multipart/form-data">
        <input type="file" name="archivo">
        <input type="submit" value="Subir">
    </form>

    <p><a href="mostrar.php">Ver archivos subidos</a></p>

</body>
</html>
