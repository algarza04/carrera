#!/bin/bash

# Ejecuta el script de iptables
./AlmDistAF-iptables-web.sh

# Fijar permisos del directorio de subida si existe
if [ -d /var/www/html/archivos ]; then
    echo "Estableciendo permisos para /var/www/html/archivos..."
    chown -R www-data:www-data /var/www/html/archivos
    chmod -R 755 /var/www/html/archivos
fi

# Comando principal del contenedor
exec "$@"
