#!/bin/bash

# Limpiar reglas existentes
iptables -F
iptables -X
iptables -Z

# Políticas por defecto: denegar todo
iptables -P INPUT DROP
iptables -P OUTPUT DROP
iptables -P FORWARD DROP

# Permitir tráfico ya establecido o relacionado
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
iptables -A OUTPUT -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT

# Permitir loopback
iptables -A INPUT -i lo -j ACCEPT
iptables -A OUTPUT -o lo -j ACCEPT

# Permitir acceso desde el balanceador (IP 192.168.10.50) a puertos HTTP y HTTPS
iptables -A INPUT -p tcp -s 192.168.10.50 --dport 80 -j ACCEPT
iptables -A INPUT -p tcp -s 192.168.10.50 --dport 443 -j ACCEPT

# REGLAS DE SEGURIDAD EJERCICIOS AVANZADOS

## 1. Limitar número de conexiones simultáneas al puerto 443 por IP
iptables -A INPUT -p tcp --dport 443 -m connlimit --connlimit-above 3 --connlimit-mask 32 -j REJECT --reject-with icmp-port-unreachable

## 2. Crear cadena para detectar escaneo de puertos tipo SYN scan
iptables -N portscan

# Permitir solo una tasa limitada de paquetes RST (indicadores de escaneo)
iptables -A portscan -p tcp --tcp-flags SYN,ACK,FIN,RST RST -m limit --limit 1/s --limit-burst 2 -j RETURN

# Si se excede el límite, se considera intento de escaneo y se descarta
iptables -A portscan -j DROP

# Aplicar portscan solo al tráfico entrante por el puerto 443
iptables -A INPUT -p tcp --dport 443 -j portscan

## 3. Limitar tasa de conexiones nuevas al puerto 443 por IP (máx 20 en 10 segundos)
iptables -A INPUT -p tcp --dport 443 -m state --state NEW \
         -m recent --set --name conn_ratelimit

iptables -A INPUT -p tcp --dport 443 -m state --state NEW \
         -m recent --update --seconds 10 --hitcount 20 --rttl --name conn_ratelimit \
         -j REJECT --reject-with icmp-port-unreachable

